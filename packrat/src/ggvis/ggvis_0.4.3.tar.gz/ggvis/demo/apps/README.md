This directory contains example Shiny apps. If you are in the top-level ggvis directory, these can be run with:

```
shiny::runApp('demo/apps/basic')
```

If you've installed `ggvis`, you can run the demo with 

```
shiny::runApp(system.file("demo/apps/basic", package = "ggvis"))
```
